package me.regexp;


/**
 * 
 *  @author Nikolay Neizvesny
 */
public class StringReader extends java.io.Reader {

	public StringReader(String str) {
	}

	public int read() {
	}

	public int read(char[] cbuf, int off, int len) {
	}

	public void close() {
	}

	public String readLine() {
	}

	public boolean ready() {
	}
}
